import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { PartnerService } from '../../partner.service';

@Component({
  selector: 'app-partner-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './partner-form.html',
  styleUrls: ['./partner-form.css']
})
export class PartnerFormComponent {

  private fb = inject(FormBuilder);
  private partnerService = inject(PartnerService);
  private router = inject(Router);

  saving = false;
  error?: string;

  form = this.fb.nonNullable.group({
    name: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    taxNumber: ['', Validators.required],
    address: ['', Validators.required]
  });

  submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.saving = true;
    this.error = undefined;

    this.partnerService.create(this.form.getRawValue()).subscribe({
      next: () => this.router.navigate(['/partners']),
      error: () => {
        this.error = 'Nem sikerült létrehozni a partnert.';
        this.saving = false;
      }
    });
  }
}
