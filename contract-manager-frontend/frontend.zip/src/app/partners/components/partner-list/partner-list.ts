import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PartnerService } from '../../partner.service';
import { Partner } from '../../partner.model';

@Component({
  selector: 'app-partner-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './partner-list.html',
  styleUrls: ['./partner-list.css']
})
export class PartnerListComponent implements OnInit {

  partners: Partner[] = [];
  loading = false;
  error?: string;

  constructor(private partnerService: PartnerService) {}

  ngOnInit(): void {
    this.loadPartners();
  }

  loadPartners(): void {
    this.loading = true;
    this.error = undefined;

    this.partnerService.getAll().subscribe({
      next: partners => {
        this.partners = partners;
        this.loading = false;
      },
      error: () => {
        this.error = 'Nem sikerült betölteni a partnereket.';
        this.loading = false;
      }
    });
  }

  deletePartner(partner: Partner): void {
    if (!confirm(`Biztosan törlöd?\n\n${partner.name}`)) {
      return;
    }

    this.partnerService.delete(partner.id).subscribe({
      next: () => this.loadPartners(),
      error: () => {
        alert('Nincs jogosultságod a törléshez.');
      }
    });
  }
}
