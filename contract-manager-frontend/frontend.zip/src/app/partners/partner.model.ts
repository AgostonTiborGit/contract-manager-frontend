export interface Partner {
  id: number;
  name: string;
  email: string;
  taxNumber: string;
  address: string;
}
