import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Partner } from './partner.model';

@Injectable({ providedIn: 'root' })
export class PartnerService {

  private readonly apiUrl = 'http://localhost:8080/api/partners';

  constructor(private http: HttpClient) {}

  getAll(): Observable<Partner[]> {
    return this.http.get<Partner[]>(this.apiUrl);
  }

  create(partner: Omit<Partner, 'id'>): Observable<void> {
    return this.http.post<void>(this.apiUrl, partner);
  }

  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}
